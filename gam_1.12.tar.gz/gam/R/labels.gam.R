labels.gam<-function(object,...){
      attr(object$terms, "term.labels")
    }
