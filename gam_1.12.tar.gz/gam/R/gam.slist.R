"gam.slist" <-
c("s", "lo", "random")
