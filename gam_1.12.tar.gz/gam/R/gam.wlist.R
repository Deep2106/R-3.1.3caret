"gam.wlist" <-
c("s","lo")

