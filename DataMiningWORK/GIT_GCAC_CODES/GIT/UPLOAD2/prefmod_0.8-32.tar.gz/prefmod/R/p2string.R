`p2string` <-
function(x) {
################################################################
# convert pattern given as vector into string
# e.g. 1,2,3,4 -> "1 2 3 4"
################################################################
  z<-paste(x,collapse=" ")
  z
}
