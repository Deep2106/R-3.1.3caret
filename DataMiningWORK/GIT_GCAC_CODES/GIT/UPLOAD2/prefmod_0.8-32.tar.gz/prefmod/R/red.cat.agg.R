#
# reduce categories (ordinal to simple)
#        with aggregated data
#        (requires function red.cat() )
#
red.cat.agg<-function(x,nrespcat) {
# no aggregated data for the time being
#
# i <- red.cat(0:nrespcat,nrespcat)
# x<-matrix(x,ncol=nrespcat+1,byrow=T)
# out<-NULL
# for (k in 1:dim(x)[1])
#   for (j in 0:max(i)){
#     out <- c(out,sum(tm[k,]*ifelse(i==j,1,0)))
# }
# out
}
