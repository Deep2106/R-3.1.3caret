/*
** The source code for establishing links to the bdsmatrix C routines is
**  found in the .h file below, which is included automatically from the 
**  inst/include directory of the bdsmatrix package by the  "LinkingTo"
**  line in ../DESCRIPTION.
** All we need is a hook (this file) to cause the lines to be compiled.
*/
#include "bdsmatrix_stub.h"
