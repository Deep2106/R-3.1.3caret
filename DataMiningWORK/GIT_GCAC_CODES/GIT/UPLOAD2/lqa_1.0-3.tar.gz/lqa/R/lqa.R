lqa <-
function (x, ...)
  UseMethod ("lqa")

