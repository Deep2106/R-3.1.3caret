penalty <-
function (x, ...)
  UseMethod ("penalty")

