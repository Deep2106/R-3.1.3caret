dev.loss <-
function (pred.obj)
{
#  cat ("predict.lqa.obj$deviance = ", predict.lqa.obj$deviance, "\n")
  return (pred.obj$deviance)
}

