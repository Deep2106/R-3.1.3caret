/*
   yesno.h 

*/

#ifndef YES
#define YES (0 == 0)
#define NO (!YES)
#endif
