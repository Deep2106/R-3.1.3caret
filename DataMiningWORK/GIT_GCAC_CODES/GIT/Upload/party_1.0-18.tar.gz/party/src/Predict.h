
void C_splitnode(SEXP node, SEXP learnsample, SEXP control);
