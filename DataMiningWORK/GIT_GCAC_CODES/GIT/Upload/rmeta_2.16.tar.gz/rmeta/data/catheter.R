"catheter" <-
structure(list(Name = c("Ciresi", "George", "Hannan", "Heard", 
"vanHeerden", "Maki", "Bach(a)", "Ramsay", "Appavu", "Trazzera", 
"Collins", "Bach(b)", "Tennenberg", "Pemberton", "Logghe"), n.trt = c(124, 
44, 68, 151, 28, 208, 14, 199, 12, 123, 98, 116, 137, 32, 338
), n.ctrl = c(127, 35, 60, 157, 26, 195, 12, 189, 7, 99, 139, 
117, 145, 40, 342), col.trt = c(15, 10, 22, 60, 4, 28, 0, 45, 
1, 16, 2, 2, 8, NA, NA), col.ctrl = c(21, 25, 22, 82, 10, 47, 
4, 63, 1, 24, 25, 16, 32, NA, NA), inf.trt = c(13, 1, 5, 5, NA, 
2, NA, 1, NA, 4, 1, 0, 5, 2, 17), inf.ctrl = c(14, 3, 7, 6, NA, 
9, NA, 4, NA, 5, 4, 3, 9, 3, 15)), row.names = c("1", "2", "3", 
"4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"
), class = "data.frame")
