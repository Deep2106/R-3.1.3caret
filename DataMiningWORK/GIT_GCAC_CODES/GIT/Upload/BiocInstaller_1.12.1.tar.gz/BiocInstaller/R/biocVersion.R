biocVersion <- function() BIOC_VERSION
