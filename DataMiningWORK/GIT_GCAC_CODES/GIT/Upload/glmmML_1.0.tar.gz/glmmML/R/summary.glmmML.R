summary.glmmML <- function(object, ...){
    print.glmmML(object, ...)
}
