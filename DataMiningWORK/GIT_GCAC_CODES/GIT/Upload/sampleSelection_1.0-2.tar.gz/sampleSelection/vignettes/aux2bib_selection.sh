aux2bib selection.aux
mv references.bib selection.bib
