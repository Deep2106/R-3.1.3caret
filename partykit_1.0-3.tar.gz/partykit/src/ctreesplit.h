
void C_split_numeric (SEXP x, SEXP y, int *weights, int minsplit, double *expinf, double *covinf, double *breaks);
void C_split_factor (SEXP x, SEXP y, int *weights, int minsplit, double *expinf, double *covinf, int *ans);
