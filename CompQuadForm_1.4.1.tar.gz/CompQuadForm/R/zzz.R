.onLoad <- function(libname, pkg){
    library.dynam("CompQuadForm", pkg, libname)
}
