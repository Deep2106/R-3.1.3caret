pchlist <- function(){
plot(rep(1:16, each = 16), rep(1:16, 16), pch = 1:256, axes = FALSE, xlab = "", 
     ylab = "")
box()
}